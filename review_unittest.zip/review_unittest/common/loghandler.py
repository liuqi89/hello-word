import logging
import os


# 一、使用函数封装
def get_log(logger_name=None,
            file_path=None,
            logger_level="DEBUG",
            stream_level="DEBUG",
            file_level="ERROR",
            fmt="%(asctime)s--%(filename)s--line:%(lineno)d--%(levelname)s:%(message)s"
            ):
    # 创建记录器、设置记录器等级
    logger = logging.getLogger(logger_name)
    logger.setLevel(logger_level)
    stream_handler = logging.StreamHandler()

    # 创建流输出器等级、
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(stream_level)

    # 将输出器 关联到 记录器
    logger.addHandler(stream_handler)

    # 设置log输出的格式
    fmt = logging.Formatter(fmt)
    stream_handler.setFormatter(fmt)

    # 如果传入文件路径，则输出log到文件中
    if file_path:
        file_handler = logging.FileHandler(file_path, encoding="utf8")
        file_handler.setLevel(file_level)
        logger.addHandler(file_handler)
        file_handler.setFormatter(fmt)

    return logger


# if __name__ == "__main__":
#     log_file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),"log","logs.txt")
#     log = get_log(file_path=log_file_path)
#
#     log.error("错误日志")
#     log.warning("警告日志")




# 二、使用类封装
class GetLog:
    def __init__(self,
            logger_name=None,
            file_path=None,
            logger_level="DEBUG",
            stream_level="DEBUG",
            file_level="ERROR",
            fmt="%(asctime)s--%(filename)s--line:%(lineno)d--%(levelname)s:%(message)s"
            ):
        # 创建记录器、流信息输出处理器，文件输出处理器
        logger = logging.getLogger(logger_name)
        stream_handler = logging.StreamHandler()

        # 设置记录器、输出器等级
        logger.setLevel(logger_level)
        stream_handler.setLevel(stream_level)

        # 将输出器 关联到 记录器
        logger.addHandler(stream_handler)

        # 设置log输出的格式
        fmt = logging.Formatter(fmt)
        stream_handler.setFormatter(fmt)

        # 如果传入文件路径，则输出log到文件中
        if file_path:
            file_handler = logging.FileHandler(file_path, encoding="utf8")
            file_handler.setLevel(file_level)
            logger.addHandler(file_handler)
            file_handler.setFormatter(fmt)

        # __init__中不能return，可以将logger对象通过self传递给类
        self.logger = logger



# 三、使用类继承封装
class GetLogInherit(logging.Logger):
    def __init__(self,
                 logger_name=None,
                 file_path=None,
                 logger_level="DEBUG",
                 stream_level="DEBUG",
                 file_level="ERROR",
                 fmt="%(asctime)s--%(filename)s--line:%(lineno)d--%(levelname)s:%(message)s"
                 ):
        """
        超继承父类logging.Logger的__init__，传入记录器的name、level。拥有Logger所有的属性和方法，使用self调用Logger。
        不需要在使用logging.getLogger(name)创建记录器，logging.getLogger(name)也是继承至logging.Logger，得到的就是Logger记录器对象
        """
        super().__init__(logger_name,logger_level)

        # 创建流信息输出处理器，设置等级，并关联到记录器上
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(stream_level)
        self.addHandler(stream_handler)

        # 设置流处理器log输出的格式
        fmt = logging.Formatter(fmt)
        stream_handler.setFormatter(fmt)

        # 如果传入文件路径，则输出log到文件中
        if file_path:
            file_handler = logging.FileHandler(file_path, encoding="utf8")
            file_handler.setLevel(file_level)
            self.addHandler(file_handler)
            file_handler.setFormatter(fmt)