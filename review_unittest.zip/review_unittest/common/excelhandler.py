import os
import openpyxl
from openpyxl import Workbook
from openpyxl.worksheet.worksheet import Worksheet

"""
# 获取用例文件路径
case_data_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),"data","case_data.xlsx")

# 加载一个workbook
workbook = openpyxl.load_workbook(case_data_path)

# 获取表单Sheet
sheet = workbook["Login"]

# 获取表单中所有行，sheet.rows得到的是生成器，可以通过遍历来使用它们，要么用一个“for”循环，要么将它们传递给任意可以进行迭代的函数和结构
# print(list(sheet.values)) # 获取表单中所有行的值，也是一个生成器
cells  = list(sheet.rows)

# 使用字典提取表格中每行数据放到表格中
case_data = []
data_lab = []
for label in cells[0]:
    data_lab.append(label.value)
for row in cells[1:]:
    dic = {}
    for key,cell in enumerate(row):
        dic[data_lab[key]]= cell.value
    case_data.append(dic)
"""



class ExcelHandler:
    def __init__(self,data_path):
        """初始化传入文件的路径"""
        self.data_path = data_path
        self.workbook: Workbook = None

    def open_file(self):
        """使用文件路径，加载 workbook"""
        workbook = openpyxl.load_workbook(self.data_path)
        self.workbook = workbook
        return workbook

    def get_sheet(self,sheet_page):
        """获取表单，sheet_page为表单名称"""
        return self.open_file()[sheet_page]

    def read_data(self,sheet_page):
        """读取表单中所有行，将提取出的数据放入列表中"""
        sheet: Worksheet = self.get_sheet(sheet_page)
        rows = list(sheet.rows)

        case_data = []
        data_lab = []
        for label in rows[0]:
            data_lab.append(label.value)
        for row in rows[1:]:
            dic = {}
            for key, cell in enumerate(row):
                dic[data_lab[key]] = cell.value
            case_data.append(dic)
        return case_data

    def close_file(self):
        self.workbook.close()

# if __name__ == "__main__":
#     case_data_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),"data", "case_data.xlsx")
#     data = ExcelHandler(case_data_path).read_data("Login")
#     print(data)