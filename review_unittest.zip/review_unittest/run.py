import os
import unittest
import HTMLTestRunner_PY3

test_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "testcases")    # 测试用例目录路径
report_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),"reports","output.html")  # 测试报告文件路径

# 实例化一个加载器
loader = unittest.TestLoader()

# 收集需要执行的用例
suit = loader.discover(test_path)

# 执行测试用例，生成报告
"""
下载python3的 HTMLTestRunner 报告(第三方的unittest报告)，下载之后放在External Libraries中或python目录Lib文件夹下
下载连接：https://github.com/huilansame/HTMLTestRunner_PY3
"""
# with open(report_path, "wb") as f:
#     run = HTMLTestRunner_PY3.HTMLTestRunner(f,verbosity=2,title="liuqi_test",description="嘿，看这里，这是一个描述")
#     run.run(suit)
run = HTMLTestRunner_PY3.HTMLTestRunner(stream=open(report_path, "wb"), verbosity=2, title="liuqi_test", description="描述")
run.run(suit)