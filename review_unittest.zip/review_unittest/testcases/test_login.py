import unittest


def login(username=None, password=None):
    if username is not None and password is not None:
        if username == "liuqi" and password == "6767":
            return {"resp": "login_success"}
        else:
            return {"resp": "login_fail"}
    else:
        return {"resp": "parameter not empty"}




class TestLogin(unittest.TestCase):

    """
    testfixture:测试脚手架，setUp，tearDown
    """
    def setUp(self) -> None:
        pass

    def tearDown(self) -> None:
        pass

    def test_success(self):
        username = "liuqi"
        password = "676"
        resp = {"resp": "login_success"}
        result = login(username, password)
        self.assertTrue(result == resp)

    def test_fail(self):
        username = "liuqi"
        password = "677"
        resp = {"resp": "login_success"}
        result = login(username, password)
        self.assertTrue(result == resp)

    def test_fial2(self):
        pass

# if __name__ == "__main__":
#     unittest.main()
